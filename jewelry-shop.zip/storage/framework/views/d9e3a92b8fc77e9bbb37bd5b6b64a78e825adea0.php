<?php
$err_title = $errors->first('title');
$err_url = $errors->first('url');
$err_article = $errors->first('article');
$err_image = $errors->first('image');
?>


<?php $__env->startSection('cms_content'); ?>

<h1>ערוך קטגוריה</h1>
<div class="ui divider"></div>

<form class="ui form" action="<?php echo e(url("cms/categories/{$category['id']}")); ?>" method="POST"
    enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

    <div class="field <?php echo e($err_title ? 'error' : null); ?>">
        <label for="title-field">כותרת</label>
        <input type="text" name="title" id="title-field" class="url-field" placeholder="כותרת"
            value="<?php echo e(old('title') ?? $category['title']); ?>">
        <span class="text-danger"><?php echo e($err_title); ?></span>
    </div>
    <div class="field <?php echo e($err_url ? 'error' : null); ?>">
        <label for="url-field">כתובת הקטגוריה ( Url )</label>
        <small>תווים מורשים: אותיות קטנות באנגלית ומקפים (-)</small>
        <input type="text" name="url" id="url-field" class="to-permalink" placeholder="כתובת הקטגוריה ( Url )"
            value="<?php echo e(old('url') ?? $category['url']); ?>">
        <span class="text-danger"><?php echo e($err_url); ?></span>
    </div>
    <div class="field <?php echo e($err_article ? 'error' : null); ?>">
        <label for="article-field">תוכן הקטגוריה</label>
        <textarea name="article" id="article-field"><?php echo e(old('article') ?? $category['article']); ?></textarea>
        <span class="text-danger"><?php echo e($err_article); ?></span>
    </div>

    <div class="field <?php echo e($err_image ? 'error' : null); ?>">
        <img src="<?php echo e(asset("images/{$category['image']}")); ?>" width="100" alt="">
        <label for="image-field">העלאת תמונה</label>
        <input type="file" name="image" id="image-field" placeholder="בחר קובץ" value="<?php echo e(old('article')); ?>">
        <span class="text-danger"><?php echo e($err_image); ?></span>
    </div>

    <a href="<?php echo e(url('cms/categories')); ?>" class="ui button">חזור</a>
    <button class="ui primary button" type="submit" name="submit">שמור</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/edit_category.blade.php ENDPATH**/ ?>