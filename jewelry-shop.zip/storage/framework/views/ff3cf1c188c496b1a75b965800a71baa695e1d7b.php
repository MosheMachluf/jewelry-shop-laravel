<?php $__env->startSection('main_content'); ?>

<div class="ui container">

    <section class="section">
        <h1 class="ui icon header page-header-icon">
            <i class="circular lock icon"></i>
            <div class="content">
                התחברות
                <p class="sub header">
                    אין לך חשבון אצלנו?
                    <a href="<?php echo e(url('user/signup')); ?>">צור חשבון</a>
                </p>
            </div>
        </h1>

        <div class="row">
            <form class="ui form" method="POST" action="">
                <?php echo csrf_field(); ?>
                <div class="field">
                    <label for="email">אימייל</label>
                    <input type="text" name="email" id="email" placeholder="אימייל" value="<?php echo e(old('email')); ?>">
                </div>
                <div class="field">
                    <label for="password">סיסמה</label>
                    <input type="password" name="password" id="password" placeholder="סיסמה">
                </div>

                <?php if($errors->first()): ?>
                <div class="ui red segment shadow text-danger tac">
                    <?php echo e($errors->first()); ?>

                </div>
                <?php endif; ?>

                <button class="ui primary button left floated" type="submit" name="submit">התחבר</button>
            </form>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/forms/signin.blade.php ENDPATH**/ ?>