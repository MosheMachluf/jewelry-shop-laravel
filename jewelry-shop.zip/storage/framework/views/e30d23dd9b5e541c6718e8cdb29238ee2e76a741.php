<a href="<?php echo e(url("shop/{$product['category_url']}/{$product['url']}")); ?>" class="product-item hover-img">
    <div class="image">
        <img src="<?php echo e(asset('images/' . $product['image'])); ?>" alt="<?php echo e($product['title']); ?>">
    </div>
    <h3><?php echo e($product['title']); ?></h3>
    <div class="number-format price <?php if($product['sale_price']): ?> original-price <?php endif; ?>">
        &#8362;<?php echo e($product['price']); ?>

    </div>
    <?php if($product['sale_price']): ?>
    <div class="number-format price text-danger">&#8362;<?php echo e($product['sale_price']); ?></div>
    <?php endif; ?>
</a>
<?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/components/product-grid.blade.php ENDPATH**/ ?>