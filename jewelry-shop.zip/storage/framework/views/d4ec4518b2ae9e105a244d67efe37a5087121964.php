<?php
$err_title = $errors->first('title');
$err_url = $errors->first('url');
$err_article = $errors->first('article');
$err_image = $errors->first('image');
?>


<?php $__env->startSection('cms_content'); ?>

<h1>הוסף קטגוריה</h1>
<div class="ui divider"></div>

<form class="ui form" action="<?php echo e(url('cms/categories')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <div class="field <?php echo e($err_title ? 'error' : null); ?>">
        <label for="title-field">כותרת</label>
        <input type="text" name="title" id="title-field" placeholder="כותרת" value="<?php echo e(old('title')); ?>">
        <span class="text-danger"><?php echo e($err_title); ?></span>
    </div>
    <div class="field <?php echo e($err_url ? 'error' : null); ?>">
        <label for="url-field">כתובת הקטגוריה ( Url )</label>
        <small>תווים מורשים: אותיות קטנות באנגלית ומקפים (-)</small>
        <input type="text" name="url" id="url-field" class="to-permalink" placeholder="כתובת הקטגוריה ( Url )"
            value="<?php echo e(old('url')); ?>">
        <span class="text-danger"><?php echo e($err_url); ?></span>
    </div>
    <div class="field <?php echo e($err_article ? 'error' : null); ?>">
        <label for="article-field">תוכן הקטגוריה</label>
        <textarea name="article" id="article-field"><?php echo e(old('article')); ?></textarea>
        <span class="text-danger"><?php echo e($err_article); ?></span>
    </div>

    <div class="field <?php echo e($err_image ? 'error' : null); ?>">
        <label for="image-field">העלאת תמונה</label>
        <input type="file" name="image" id="image-field" value="<?php echo e(old('image')); ?>" placeholder="בחר קובץ">
        <span class="text-danger"><?php echo e($err_image); ?></span>
    </div>

    <a href="<?php echo e(url('cms/categories')); ?>" class="ui button">חזור</a>
    <button class="ui primary button" type="submit" name="submit">הוסף</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/add_category.blade.php ENDPATH**/ ?>