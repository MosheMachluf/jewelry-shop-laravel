<?php $__env->startSection('cms_content'); ?>

<h1 class="ui horizontal divider header">מוצרים</h1>


<a href="<?php echo e(url('cms/products/create')); ?>" class="ui button positive">הוסף מוצר חדש <i class="add icon"></i></a>

<div class="ui segment shadow mt-2">
    <table class="ui very basic selectable table">
        <thead>
            <tr>
                <th>פעולות</th>
                <th>קטגוריה</th>
                <th>מוצר</th>
                <th>מחיר</th>
                <th>עודכן לאחרונה</th>
                <th>נוצר</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href=" <?php echo e(url("cms/products/{$product->id}")); ?>" class="text-danger" data-tooltip="מחק"
                        data-inverted=""><i class="delete icon"></i></a>
                    <a href="<?php echo e(url("cms/products/{$product->id}/edit")); ?>" data-tooltip="ערוך" data-inverted=""><i
                            class="pencil icon"></i></a>
                </td>
                <td>
                    <a target="_blank" href="<?php echo e(url("shop/{$product->category_url}")); ?>"><?php echo e($product->category); ?></a>
                </td>
                <td>
                    <a target="_blank" href="<?php echo e(url("images/{$product->image}")); ?>">
                        <img src="<?php echo e(asset("images/{$product->image}")); ?>" alt="<?php echo e($product->title); ?>" width="50">
                    </a>
                    <a target="_blank"
                        href="<?php echo e(url("shop/{$product->category_url}/{$product->url}")); ?>"><?php echo e($product->title); ?>

                    </a>
                </td>
                <td class="number-format">&#8362;<?php echo e($product->price); ?></td>
                <td><?php echo e($product->updated_at); ?></td>
                <td><?php echo e($product->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/products.blade.php ENDPATH**/ ?>