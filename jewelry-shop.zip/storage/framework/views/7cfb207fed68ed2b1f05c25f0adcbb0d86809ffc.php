<?php $__env->startSection('cms_content'); ?>

<h1 class="ui horizontal divider header">הזמנות</h1>

<a href="<?php echo e(url('cms/orders')); ?>" class="ui blue button <?php echo e(request()->display === 'table' ? 'basic' : ''); ?>">
    תצוגת כרטיסים
    <i class="address card icon"></i>
</a>
<a href="<?php echo e(url('cms/orders?display=table')); ?>"
    class="ui blue button <?php echo e(request()->display === 'table' ? '' : 'basic'); ?>">
    תצוגת טבלה <i class="table icon"></i>
</a>

<?php if(request()->display === 'table'): ?>

<div class="ui segment shadow mt-2">
    <table class="ui very basic selectable table">
        <thead>
            <tr>
                <th>שם מלא</th>
                <th>פרטי הזמנה</th>
                <th>סכום</th>
                <th>עודכן לאחרונה</th>
                <th>נוצר</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->full_name); ?></td>
                <td class="ui accordion">
                    <a class="title">לחץ לפרטים <i class="dropdown icon"></i></a>
                    <ul class="content">

                        <?php $__currentLoopData = unserialize($order->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <p>
                                <div>
                                    <?php if($product['attributes']): ?>
                                    <img src="<?php echo e(asset("images/{$product['attributes'][0]}")); ?>" width="50">
                                    <?php endif; ?>
                                    <?php echo e($product['name']); ?>


                                </div>
                                <div>
                                    <strong> מחיר: </strong>
                                    <?php echo e($product['price']); ?>&#8362;
                                </div>
                                <div>
                                    <strong> כמות: </strong>
                                    <?php echo e($product['quantity']); ?>

                                </div>
                            </p>
                            <div class="ui divider"></div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </td>
                <td class="number-format"><?php echo e($order->total); ?>&#8362;</td>
                <td><?php echo e($order->updated_at); ?></td>
                <td><?php echo e($order->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

<?php else: ?>

<div class="ui stackable four column grid mt-2">

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="column">
        <div class="ui segment shadow border-style">
            <?php echo e($order->full_name); ?>

            <hr>

            <?php $__currentLoopData = unserialize($order->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($product['name']); ?> |
            מחיר: <?php echo e($product['price']); ?> |
            כמות: <?php echo e($product['quantity']); ?>

            <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <span class="ui aligned left"><?php echo e($order->total); ?></span>
        </div>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php endif; ?>
<?php echo e($orders->withQueryString('display')->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/orders.blade.php ENDPATH**/ ?>