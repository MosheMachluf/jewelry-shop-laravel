<div class="ui breadcrumb">
    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="section" href="<?php echo e(url($val)); ?>"><?php echo e($key); ?></a>
    <i class="left angle icon divider"></i>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="active section"><?php echo e($current); ?></div>
</div>
<?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>