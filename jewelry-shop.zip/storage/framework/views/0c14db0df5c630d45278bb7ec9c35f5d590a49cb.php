<?php $__env->startSection('cms_content'); ?>

<h1 class="ui horizontal divider header">ניהול משתמשים</h1>

<a href="<?php echo e(url('cms/users/create')); ?>" class="ui button positive">הוסף משתמש חדש <i class="add icon"></i></a>
<div class="ui segment shadow mt-2">
    <table class="ui very basic selectable table">
        <thead>
            <tr>
                <th>פעולות</th>
                <th>#</th>
                <th>שם מלא</th>
                <th>אימייל</th>
                <th>עודכן לאחרונה</th>
                <th>נוצר</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr class="<?php echo e($user['id'] === 1 ? 'disabled negative' : null); ?>">
                <td>
                    <?php if($user['id'] !== 1): ?>
                    <a href=" <?php echo e(url("cms/users/{$user['id']}")); ?>" class="text-danger" data-tooltip="מחק"
                        data-inverted="">
                        <i class="delete icon"></i></a>
                    <a href="<?php echo e(url("cms/users/{$user['id']}/edit")); ?>" data-tooltip="ערוך" data-inverted="">
                        <i class="pencil icon"></i></a>
                    <?php endif; ?>
                </td>
                <td><?php echo e($user['id']); ?></td>
                <td class="capitalize"><?php echo e($user['full_name']); ?></td>
                <td><?php echo e($user['email']); ?></td>
                <td><?php echo e($user['updated_at']); ?></td>
                <td><?php echo e($user['created_at']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/users.blade.php ENDPATH**/ ?>