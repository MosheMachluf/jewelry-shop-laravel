<?php
$err_category = $errors->first('category');
$err_url = $errors->first('url');
$err_title = $errors->first('title');
$err_article = $errors->first('article');
$err_price = $errors->first('price');
$err_sale_price = $errors->first('sale_price');
$err_image = $errors->first('image');
?>


<?php $__env->startSection('cms_content'); ?>

<h1>ערוך מוצר</h1>
<div class="ui divider"></div>

<form class="ui form" action="<?php echo e(url("cms/products/{$product['id']}")); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="item_id" value="<?php echo e($product['id']); ?>">
    <div class="two fields">
        <div class="field <?php echo e($err_title ? 'error' : null); ?>">
            <label for="title-field">כותרת</label>
            <input type="text" name="title" id="title-field" class="url-field" placeholder="כותרת"
                value="<?php echo e(old('title') ?? $product['title']); ?>">
            <span class="text-danger"><?php echo e($err_title); ?></span>
        </div>

        <div class="field <?php echo e($err_category ? 'error' : null); ?>">
            <label for="category-field">קטגוריה</label>
            <select class="ui search dropdown" id="category-field" name="category_id">

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category['id']); ?>" <?php if($product['category_id']==$category['id']): ?> selected='selected'
                    <?php endif; ?>>
                    <?php echo e($category['title']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
            <span class="text-danger"><?php echo e($err_category); ?></span>
        </div>
    </div>

    <div class="three fields">
        <div class="field <?php echo e($err_url ? 'error' : null); ?>">
            <label for="url-field">כתובת המוצר ( Url )</label>
            <input type="text" name="url" id="url-field" class="to-permalink" placeholder="כתובת המוצר ( Url )"
                value="<?php echo e(old('url') ?? $product['url']); ?>">
            <small>תווים מורשים: אותיות קטנות באנגלית ומקפים (-)</small>
            <span class="text-danger"><?php echo e($err_url); ?></span>
        </div>

        <div class="field <?php echo e($err_price ? 'error' : null); ?>">
            <label for="price-field">מחיר</label>
            <input type="number" name="price" id="price-field" placeholder="מחיר"
                value="<?php echo e(old('price') ?? $product['price']); ?>">
            <span class="text-danger"><?php echo e($err_price); ?></span>
        </div>

        <div class="field <?php echo e($err_sale_price ? 'error' : null); ?>">
            <label for="sale-price-field">מחיר מבצע</label>
            <input type="text" name="sale_price" id="sale-price-field" placeholder="מחיר מבצע"
                value="<?php echo e(old('sale_price') ?? $product['sale_price']); ?>">
            <span class="text-danger"><?php echo e($err_sale_price); ?></span>
        </div>
    </div>

    <div class="field <?php echo e($err_article ? 'error' : null); ?>">
        <label for="article-field">תוכן המוצר</label>
        <textarea name="article" id="article-field"><?php echo e(old('article') ?? $product['article']); ?></textarea>
        <span class="text-danger"><?php echo e($err_article); ?></span>
    </div>

    <div class="field <?php echo e($err_image ? 'error' : null); ?>">
        <label for="image-field">העלאת תמונה</label>
        <input type="file" name="image" id="image-field" value="<?php echo e(old('image') ?? $product['image']); ?>"
            placeholder="בחר קובץ">
        <span class="text-danger"><?php echo e($err_image); ?></span>
    </div>

    <a href="<?php echo e(url('cms/products')); ?>" class="ui button">חזור</a>
    <button class="ui primary button" type="submit" name="submit">שמור</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/edit_product.blade.php ENDPATH**/ ?>