<?php $__env->startSection('cms_content'); ?>

<h1 class="ui horizontal divider header">תכני אתר</h1>


<a href="<?php echo e(url('cms/contents/create')); ?>" class="ui button positive">הוסף תוכן חדש <i class="add icon"></i></a>


<div class="ui segment shadow mt-2">
    <table class="ui very basic selectable table">
        <thead>
            <tr>
                <th>פעולות</th>
                <th>כותרת</th>
                <th>לינק</th>
                <th>עודכן לאחרונה</th>
                <th>נוצר</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(url("cms/contents/{$content['id']}")); ?>" class="text-danger" data-tooltip="מחק"
                        data-inverted="">
                        <i class="delete icon"></i>
                    </a>
                    <a href="<?php echo e(url("cms/contents/{$content['id']}/edit")); ?>" data-tooltip="ערוך" data-inverted="">
                        <i class="pencil icon"></i>
                    </a>
                </td>
                <td><?php echo e($content['title']); ?></td>
                <td>
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item['id'] === $content['menu_id']): ?>
                    <a target="_blank" href="<?php echo e(url($item['url'])); ?>">
                        <?php echo e($item['title']); ?>

                    </a>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($content['updated_at']); ?></td>
                <td><?php echo e($content['created_at']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/contents.blade.php ENDPATH**/ ?>