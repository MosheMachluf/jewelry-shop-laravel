<?php
$err_name = $errors->first('name');
$err_email = $errors->first('email');
$err_password = $errors->first('password');
$err_cpassword = $errors->first('password_confirmation');
?>


<?php $__env->startSection('cms_content'); ?>

<h1><i class="add icon"></i> הוסף משתמש</h1>
<div class="ui divider"></div>

<form class="ui form" action="<?php echo e(url('cms/users')); ?>" method="POST" novalidate="novalidate">
    <?php echo e(csrf_field()); ?>


    <div class="field ">
        <label for="name-field">הרשאות</label>
        <select class="ui search dropdown" id="role-field" name="role_id">
            <option value="">בחר הרשאה ...</option>

            <?php $__currentLoopData = $user_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option class="capitalize" value="<?php echo e($role->id); ?>" <?php if(old('role_id')==$role->id): ?> selected='selected'
                <?php endif; ?>>
                <?php echo e($role->title); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
        <span class="text-danger"></span>
    </div>

    <div class="field <?php echo e($err_name ? 'error' : null); ?>">
        <label for="name-field">שם מלא</label>
        <input type="text" name="name" id="name-field" placeholder="שם מלא" value="<?php echo e(old('name')); ?>">
        <span class="text-danger"><?php echo e($err_name); ?></span>
    </div>

    <div class="field <?php echo e($err_email ? 'error' : null); ?>">
        <label for="email-field">אימייל</label>
        <input type="email" name="email" id="email-field" placeholder="אימייל" value="<?php echo e(old('email')); ?>">
        <span class="text-danger"><?php echo e($err_email); ?></span>
    </div>

    <div class="field <?php echo e($err_cpassword ? 'error' : null); ?>">
        <label for="password-field">סיסמה</label>
        <input type="password" name="password" id="password-field" placeholder="******" value="<?php echo e(old('password')); ?>">
        <span class="text-danger"><?php echo e($err_password); ?></span>
    </div>

    <div class="field <?php echo e($err_cpassword ? 'error' : null); ?>">
        <label for="cpassword-field">אימות סיסמה</label>
        <input type="password" name="password_confirmation" id="cpassword-field" placeholder="******"
            value="<?php echo e(old('password_confirmation')); ?>">
        <span class="text-danger"><?php echo e($err_cpassword); ?></span>
    </div>

    <a href="<?php echo e(url('cms/users')); ?>" class="ui button">חזור</a>
    <button class="ui primary button" type="submit" name="submit">הוסף</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/add_user.blade.php ENDPATH**/ ?>