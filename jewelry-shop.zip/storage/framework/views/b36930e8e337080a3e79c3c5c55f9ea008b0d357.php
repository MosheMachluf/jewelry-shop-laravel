<?php $__env->startSection('main_content'); ?>

<div class="ui container">
    <section class="section">
        <h1 class="ui icon header page-header-icon">
            <i class="circular lock icon"></i>
            <div class="content">
                הרשמה
                <p class="sub header">
                    כבר רשום?
                    <a href="<?php echo e(url('user/signin')); ?>">התחבר</a>
                </p>
            </div>
        </h1>

        <div class="row">
            <form class="ui form" method="POST" action="">
                <?php echo csrf_field(); ?>
                <div class="field">
                    <label for="name">שם מלא</label>
                    <input type="text" name="name" id="name" placeholder="שם מלא" value="<?php echo e(old('name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="field">
                    <label for="email">אימייל</label>
                    <input type="text" name="email" id="email" placeholder="אימייל" value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="field">
                    <label for="password">סיסמה</label>
                    <input type="password" name="password" id="password" placeholder="******">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="field">
                    <label for="password-confirmation">אימות סיסמה</label>
                    <input type="password" name="password_confirmation" id="password-confirmation" placeholder="******">
                </div>
                <button class="ui button primary left floated" type="submit" name="submit">הרשם</button>
            </form>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/forms/Signup.blade.php ENDPATH**/ ?>