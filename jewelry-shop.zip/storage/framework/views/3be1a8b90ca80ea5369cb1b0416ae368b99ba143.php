<?php
$title = "Mosh's Jewelry | Page Not Found - 404";
$menu = App\Menu::all();
$categories = App\Category::all();
?>


<?php $__env->startSection('main_content'); ?>
<div class="ui container">
    <section class="section">
        <h1>הדף המבוקש לא נמצא</h1>
        <p>שגיאת 404</p>
        <a href="<?php echo e(asset('')); ?>">
            <i class="arrow circle right icon"></i>
            חזור לדף הבית
        </a>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/errors/404.blade.php ENDPATH**/ ?>