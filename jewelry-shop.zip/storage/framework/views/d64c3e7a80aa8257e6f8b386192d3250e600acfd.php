<?php
$err_menu = $errors->first('menu_id');
$err_title = $errors->first('title');
$err_article = $errors->first('article');
?>


<?php $__env->startSection('cms_content'); ?>

<h1>ערוך תוכן</h1>
<div class="ui divider"></div>

<form class="ui form" action="<?php echo e(url("cms/contents/{$content['id']}")); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

    <div class="ui form">
        <div class="two fields">
            <div class="field <?php echo e($err_title ? 'error' : null); ?>">
                <label for="title-field">כותרת הדף</label>
                <input type="text" name="title" id="title-field" value="<?php echo e(old('title') ?? $content['title']); ?>">
                <span class="text-danger"><?php echo e($err_title); ?></span>
            </div>

            <div class="field <?php echo e($err_menu ? 'error' : null); ?>">
                <label for="page-field">תפריט</label>
                <select class="ui search dropdown" id="page-field" name="menu_id">

                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e(old('menu_id') ?? $item['id']); ?>" <?php if($content['menu_id']==$item['id']): ?>
                        selected='selected' <?php endif; ?>>
                        <?php echo e($item['link']); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <span class="text-danger"><?php echo e($err_menu); ?></span>
            </div>

        </div>

        <div class="field <?php echo e($err_article ? 'error' : null); ?>">
            <label for="article-field">תוכן הדף</label>
            <textarea name="article" id="article-field"><?php echo e(old('article') ?? $content['article']); ?></textarea>
            <span class="text-danger"><?php echo e($err_article); ?></span>
        </div>

        <a href="<?php echo e(url('cms/contents')); ?>" class="ui button">חזור</a>
        <button class="ui primary button" type="submit" name="submit">עדכן</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/edit_content.blade.php ENDPATH**/ ?>