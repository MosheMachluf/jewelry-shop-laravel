<?php $__env->startSection('cms_content'); ?>

<h1 class="ui horizontal divider header">קטגוריות</h1>


<a href="<?php echo e(url('cms/categories/create')); ?>" class="ui button positive">הוסף קטגוריה חדשה <i class="add icon"></i></a>

<div class="ui segment shadow mt-2">
    <table class="ui very basic selectable table">
        <thead>
            <tr>
                <th>פעולות</th>
                <th>קטגוריה</th>
                <th>מס' מוצרים</th>
                <th>עודכן לאחרונה</th>
                <th>נוצר</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href=" <?php echo e(url("cms/categories/{$category['id']}")); ?>" class="text-danger" data-tooltip="מחק"
                        data-inverted="">
                        <i class="delete icon"></i>
                    </a>
                    <a href="<?php echo e(url("cms/categories/{$category['id']}/edit")); ?>" data-tooltip="ערוך" data-inverted="">
                        <i class="pencil icon"></i>
                    </a>
                </td>
                <td>
                    <a target="_blank" href="<?php echo e(url("images/{$category['image']}")); ?>">
                        <img src="<?php echo e(asset("images/{$category['image']}")); ?>" alt="<?php echo e($category['title']); ?>" width="50">
                    </a>
                    <a target="_blank" href="<?php echo e(url("shop/{$category['url']}")); ?>"><?php echo e($category['title']); ?></a>
                </td>
                <td>
                    <?php $__currentLoopData = $count_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category['id'] == $count['category_id']): ?>
                    <?php echo e($count['number']); ?>

                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td><?php echo e($category['updated_at']); ?></td>
                <td><?php echo e($category['created_at']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/categories.blade.php ENDPATH**/ ?>