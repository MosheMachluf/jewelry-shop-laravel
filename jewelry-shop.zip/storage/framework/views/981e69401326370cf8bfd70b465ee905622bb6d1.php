<?php $__env->startSection('cms_content'); ?>

<h1 class="ui horizontal divider header">פאנל ראשי</h1>

<section class="dashboard-summery">
    <div class="row">
        <div class="summery-item">
            <div class="card silver">
                <div class="content">
                    <p class="h3 font-thin"><?php echo e($total_products); ?></p>
                    <h4 class="m-0">מוצרים בחנות</h4>
                    <div>
                        <strong><?php echo e($today_products); ?></strong>
                        מוצרים היום
                    </div>
                </div>
                <div class="icon">
                    <i class="gem outline icon"></i>
                </div>
            </div>
        </div>
        <div class="summery-item">
            <div class="card gold">
                <div class="content">
                    <p class="h3 font-thin"><?php echo e($total_categories); ?></p>
                    <h4 class="m-0">קטגוריות בחנות</h4>
                    <div>
                        <strong><?php echo e($today_categories); ?></strong>
                        קטגוריות היום
                    </div>
                </div>
                <div class="icon">
                    <i class="list alternate outline icon"></i>
                </div>
            </div>
        </div>
        <div class="summery-item">
            <div class="card silver">
                <div class="content">
                    <p class="h3 font-thin"><?php echo e($total_orders); ?></p>
                    <h4 class="m-0">הזמנות בחנות</h4>
                    <div>
                        <strong><?php echo e($today_orders); ?></strong>
                        הזמנות היום
                    </div>
                </div>
                <div class="icon">
                    <i class="shipping fast icon"></i>
                </div>
            </div>
        </div>
        <div class="summery-item">
            <div class="card gold">
                <div class="content">
                    <p class="h3 font-thin"><?php echo e($total_users); ?></p>
                    <h4 class="m-0">משתמשים בחנות</h4>
                    <div>
                        <strong><?php echo e($today_users); ?></strong>
                        משתמשים היום
                    </div>
                </div>

                <div class="icon">
                    <i class="user circle icon"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="row">
    <section class="section shortcuts">
        <h3>הזמנות אחרונות</h3>
        <div class="ui segment shadow short-item">
            הזמנות אחרונות
        </div>
        <div class="ui segment shadow short-item">
            הזמנות אחרונות
        </div>
        <div class="ui segment shadow short-item">
            הזמנות אחרונות
        </div>
        <div class="ui segment shadow short-item">
            הזמנות אחרונות
        </div>
    </section>
    <section class="section shortcuts">
        <h3>הזמנות אחרונות</h3>
        <div class="ui segment shadow short-item">
            הזמנות אחרונות
        </div>
        <div class="ui segment shadow short-item">
            הזמנות אחרונות
        </div>
        <div class="ui segment shadow short-item">
            הזמנות אחרונות
        </div>
        <div class="ui segment shadow short-item">
            הזמנות אחרונות
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/dashboard.blade.php ENDPATH**/ ?>