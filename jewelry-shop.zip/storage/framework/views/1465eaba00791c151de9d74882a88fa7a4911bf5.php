<?php
$err_name = $errors->first('name');
$err_email = $errors->first('email');
$err_password = $errors->first('password');
$err_cpassword = $errors->first('password_confirmation');
?>


<?php $__env->startSection('cms_content'); ?>

<h1><i class="pencil icon"></i> ערוך משתמש</h1>
<div class="ui divider"></div>

<form class="ui form" action="<?php echo e(url("cms/users/{$user->id}")); ?>" method="POST" novalidate="novalidate">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="item_id" value="<?php echo e($user->id); ?>">
    <div class="field">
        <label for="name-field">הרשאות</label>
        <select class="ui search dropdown" id="role-field" name="role_id">

            <?php $__currentLoopData = $user_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($role->id); ?>" <?php if($user->role_id==$role->id): ?> selected='selected'
                <?php endif; ?>>
                <?php echo e($role->title); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
        <span class="text-danger"></span>
    </div>

    <div class="field <?php echo e($err_name ? 'error' : null); ?>">
        <label for="name-field">שם מלא</label>
        <input type="text" name="name" id="name-field" placeholder="שם מלא"
            value="<?php echo e(old('name') ?? $user->full_name); ?>">
        <span class="text-danger"><?php echo e($err_name); ?></span>
    </div>

    <div class="field <?php echo e($err_email ? 'error' : null); ?>">
        <label for="email-field">אימייל</label>
        <input type="email" name="email" id="email-field" placeholder="אימייל"
            value="<?php echo e(old('email') ?? $user->email); ?>">
        <span class="text-danger"><?php echo e($err_email); ?></span>
    </div>

    <div class="field <?php echo e($err_cpassword ? 'error' : null); ?>">
        <label for="password-field">סיסמה</label>
        <input type="password" name="password" id="password-field" placeholder="******">
        <span class="text-danger"><?php echo e($err_password); ?></span>
    </div>

    <div class="field <?php echo e($err_cpassword ? 'error' : null); ?>">
        <label for="cpassword-field">אימות סיסמה</label>
        <input type="password" name="password_confirmation" id="cpassword-field" placeholder="******">
        <span class="text-danger"><?php echo e($err_cpassword); ?></span>
    </div>

    <a href="<?php echo e(url('cms/users')); ?>" class="ui button">חזור</a>
    <button class="ui primary button" type="submit" name="submit">שמור</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/edit_user.blade.php ENDPATH**/ ?>