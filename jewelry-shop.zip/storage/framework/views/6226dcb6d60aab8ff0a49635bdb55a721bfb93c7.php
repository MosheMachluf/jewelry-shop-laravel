<?php $__env->startSection('main_content'); ?>

<div class="ui container">
    <section class="section">
        <h1><?php echo e(str_replace('Mosh\'s Jewelry | ','', $title)); ?></h1>
        <div class="ui divider"></div>

        <?php if($cart): ?>
        <table class="ui basic selectable table">
            <thead>
                <tr>
                    <th></th>
                    <th>מוצר</th>
                    <th>כמות</th>
                    <th>מחיר</th>
                    <th>סה"כ</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="negative">
                        <a href="<?php echo e(url('shop/remove-item/' . $item['id'])); ?>"><i class="times circle icon red"></i></a>
                    </td>
                    <td>
                        <?php if($item['attributes']): ?>
                        <img src="<?php echo e(asset("images/{$item['attributes'][0]}")); ?>" width="50">
                        <?php endif; ?>
                        <?php echo e($item['name']); ?>

                    </td>
                    <td>
                        <button value="<?php echo e($item['id']); ?>" class="update-cart ui button mini">-</button>
                        <input class="input" type="number" class="quantity" size="1" value="<?php echo e($item['quantity']); ?>"
                            disabled="disabled">
                        <button value="<?php echo e($item['id']); ?>" class="update-cart ui button mini">+</button>
                    </td>
                    <td>&#8362;<?php echo e($item['price']); ?></td>
                    <td>&#8362;<?php echo e($item['price'] * $item['quantity']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot class="full-width">
                <tr>
                    <th colspan="5">
                        <div class="flex-between">
                            <a href="<?php echo e(url('shop/clear-cart')); ?>" class="ui button">רוקן עגלה</a>
                            <div class="h5 tac"><b>סה"כ:</b> &#8362;<?php echo e(Cart::getTotal()); ?></div>
                        </div>
                    </th>
                </tr>
            </tfoot>
        </table>


        <a href="<?php echo e(url('shop/purchase')); ?>" class="ui button primary left floated">
            רכישה
            <i class="angle double left icon"></i>
        </a>


        <?php else: ?>

        <p>עגלת הקניות שלך ריקה כרגע.</p>

        <?php endif; ?>

        <a href="<?php echo e(url('shop')); ?>" class="ui basic button">
            <i class="arrow circle right icon"></i>
            המשך קנייה
        </a>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/content/checkout.blade.php ENDPATH**/ ?>