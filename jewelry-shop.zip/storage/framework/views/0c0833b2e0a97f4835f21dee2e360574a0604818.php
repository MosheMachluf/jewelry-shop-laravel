<?php $__env->startSection('cms_content'); ?>


<h1 class="ui horizontal divider header">תפריט ניווט חנות</h1>

<a href="<?php echo e(url('cms/menu/create')); ?>" class="ui button positive">הוסף לינק חדש <i class="add icon"></i></a>

<div class="ui segment shadow mt-2">
    <table class="ui very basic selectable table">
        <thead>
            <tr>
                <th>פעולות</th>
                <th>לינק</th>
                <th>עודכן לאחרונה</th>
                <th>נוצר</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(url("cms/menu/{$item['id']}")); ?>" class="text-danger" data-tooltip="מחק"
                        data-inverted=""><i class="delete icon"></i></a>
                    <a href="<?php echo e(url("cms/menu/{$item['id']}/edit")); ?>" data-tooltip="ערוך" data-inverted=""><i
                            class="pencil icon"></i></a>
                </td>
                <td><a target="_blank" href="<?php echo e(url($item['url'])); ?>"><?php echo e($item['link']); ?></a></td>
                <td><?php echo e($item['updated_at']); ?></td>
                <td><?php echo e($item['created_at']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/menu.blade.php ENDPATH**/ ?>