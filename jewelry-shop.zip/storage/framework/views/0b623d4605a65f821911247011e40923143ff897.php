<?php $__env->startSection('main_content'); ?>

<div class="ui container wide">
    <section class="section catalog">
        <div class="row">
            <div class="ui secondary vertical pointing menu sidebar-categories">
                <div class="item">
                    <div class="header tac">קטגוריות</div>
                </div>
                <a href="<?php echo e(url($u = 'shop/sale')); ?>"
                    class="item text-danger <?php echo e($u == request()->path() ? 'active' : ''); ?>">
                    ★ SALE ★
                </a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url($u = 'shop/' . $category['url'])); ?>"
                    class="item <?php echo e($u == request()->path() ? 'active' : ''); ?>">
                    <?php echo e($category['title']); ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="header tac">סינון</div>
                    <form action="">
                        <label for="">טווח מחירים</label>
                        <input type="range" name="" id="">
                        <button>סנן</button>
                    </form>
                </div>
            </div>


            <div class="products">
                <h1><?php echo e(str_replace('Mosh\'s Jewelry | ','', $title)); ?></h1>

                <div class="row header">
                    <div class="choose-display">
                        <strong>
                            תצוגה:
                        </strong>
                        <a href="<?php echo e(route('shop', ['display' => 'list'])); ?>" data-tooltip="רשימה" data-inverted="">
                            <i class="list alternate outline icon"></i>
                        </a>
                        <a href="<?php echo e(route('shop', ['display' => 'grid'])); ?>" data-tooltip="רשת" data-inverted="">
                            <i class="th icon"></i>
                        </a>
                    </div>

                    <div class="counter-results light-text">
                        מציג <?php echo e($products->count()); ?>

                        מתוך <?php echo e($products->total()); ?> תוצאות
                    </div>

                    <div class="sort-products">
                        <label for="sort-products" class="bold">
                            מיין לפי:
                        </label>
                        <select name="sort_products" id="sort-products">
                            <option value="<?php echo e(route('shop')); ?>">כללי</option>
                            <option value="<?php echo e(route('shop', ['sortBy' => 'newProd'])); ?>">מהחדש לישן</option>
                            <option value="<?php echo e(route('shop', ['sortBy' => 'priceLow'])); ?>">המחיר מהנמוך לגבוה</option>
                            <option value="<?php echo e(route('shop', ['sortBy' => 'priceHigh'])); ?>">המחיר מהגבוה לנמוך</option>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <?php if(request()->display == 'list'): ?>
                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.product-line','data' => ['product' => $product]]); ?>
<?php $component->withName('product-line'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                    <?php else: ?>
                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.product-grid','data' => ['product' => $product]]); ?>
<?php $component->withName('product-grid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <p><i>אין כרגע מוצרים באתר.</i></p>

                    <?php endif; ?>

                </div>

                <?php echo e($products->appends(request()->input())->links()); ?>


            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/content/shop.blade.php ENDPATH**/ ?>