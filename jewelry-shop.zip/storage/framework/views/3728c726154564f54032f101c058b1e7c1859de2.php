<?php $__env->startSection('main_content'); ?>

<div class="product-page ui container">
    <section class="section product">

        <div class="row">
            <div class="image hover-img">
                <img src="<?php echo e(asset('images/' . $product['image'])); ?>" alt="<?php echo e($product['title']); ?>"
                    id="product-page-img">
            </div>

            <div class="product-content">
                <div class="product-details">
                    <h1 class="product-page-title"><?php echo e($product['title']); ?></h1>
                    <div class="product-page-price number-format my-md">&#8362;<?php echo e($product['price']); ?></div>
                    <p><?php echo $product['article']; ?></p>
                </div>

                <div class="product-page-buttons">
                    <?php if(!Cart::get($product['id'])): ?>

                    <button data-id="<?php echo e($product['id']); ?>" class="ui basic button primary add-to-cart">
                        הוסף לעגלה <i class="shopping cart icon"></i>
                    </button>

                    <?php else: ?>

                    <button class="ui button" disabled="disabled">
                        המוצר בעגלה <i class="shopping cart icon"></i>
                    </button>

                    <?php endif; ?>

                    <a href="<?php echo e(url("shop/checkout?prd={$product['id']}")); ?>"
                        class="ui button primary purchase-btn">רכישה</a>
                </div>

            </div>
        </div>
    </section>

    <section class="section more-products sub-view">
        <h3 class="ui horizontal divider header">אולי יעניין אותך</h3>

        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $more_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $more_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(url("shop/{$more_product['category_url']}/{$more_product['url']}")); ?>"
                class="product-item hover-img">
                <div class="image">
                    <img src="<?php echo e(asset('images/' . $more_product['image'])); ?>" alt="<?php echo e($more_product['title']); ?>">
                </div>
                <h3 class="truncate"><?php echo e($more_product['title']); ?></h3>
                <div class="number-format price">&#8362;<?php echo e($more_product['price']); ?></div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/content/item.blade.php ENDPATH**/ ?>