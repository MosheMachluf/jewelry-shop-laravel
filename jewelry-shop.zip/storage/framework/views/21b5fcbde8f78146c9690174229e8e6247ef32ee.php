<a href="<?php echo e(url("shop/{$product['category_url']}/{$product['url']}")); ?>" class="product-list-line">
    <div class="image">
        <img src="<?php echo e(asset('images/' . $product['image'])); ?>" alt="<?php echo e($product['title']); ?>">
    </div>
    <div class="product-line-content">
        <div class="product-line-details">
            <h3><?php echo e($product['title']); ?></h3>
            
            <p><?php echo substr(strip_tags($product['article']), 0, 80); ?>...</p>
        </div>

        <div class="product-line-prices">
            <div class="number-format price <?php if($product['sale_price']): ?> original-price <?php endif; ?>">
                &#8362;<?php echo e($product['price']); ?>

            </div>
            <?php if($product['sale_price']): ?>
            <div class="number-format price">&#8362;<?php echo e($product['sale_price']); ?></div>
            <?php endif; ?>
        </div>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/components/product-line.blade.php ENDPATH**/ ?>