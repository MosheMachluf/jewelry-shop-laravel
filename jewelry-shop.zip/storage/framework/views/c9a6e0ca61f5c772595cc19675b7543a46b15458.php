<?php $__env->startSection('main_content'); ?>

<section id="slider-welcome">
    <div class="owl-carousel owl-theme">
        <div class="item"><img src="<?php echo e(asset('images/slider-welcome/1.jpg')); ?>" alt=""></div>
        <div class="item"><img src="<?php echo e(asset('images/slider-welcome/2.jpg')); ?>" alt=""></div>
        <div class="item"><img src="<?php echo e(asset('images/slider-welcome/3.jpg')); ?>" alt=""></div>
    </div>
</section>

<div class="ui container home">
    <section class="categories mt-sm">
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('shop/' . $category['url'])); ?>" class="category-item">
                <div class="image hover-img bg-hover">
                    <img src="<?php echo e(asset('images/' . $category['image'])); ?>" class="image bg-hover" alt="">
                    <h3><?php echo e($category['title']); ?></h3>
                    <p class="category-p"><?php echo $category['article']; ?></p>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="tac">
            <a href="<?php echo e(url('shop/')); ?>" class="ui button primary">
                כל הקטגוריות
                <i class="angle double left icon"></i>
            </a>
        </div>
    </section>

    <section class="top-sale sub-view">
        <h2 class="ui horizontal divider header text-danger">&#9733; SALE &#9733;</h2>

        <div class="row">
            <?php $__currentLoopData = $products_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.product-grid','data' => ['product' => $product]]); ?>
<?php $component->withName('product-grid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="tac">
            <a href="<?php echo e(url('shop/')); ?>" class="ui button primary">
                כל המבצעים
                <i class="angle double left icon"></i>
            </a>
        </div>
    </section>

    <section class="new-collection sub-view">
        <h2 class="ui horizontal divider header">
            קולקציה חדשה
        </h2>

        <div class="row">
            <?php $__currentLoopData = $new_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.product-grid','data' => ['product' => $product]]); ?>
<?php $component->withName('product-grid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="tac">
            <a href="<?php echo e(url('shop/')); ?>" class="ui button primary">
                כל המוצרים
                <i class="angle double left icon"></i>
            </a>
        </div>
    </section>



    

    <section class="clients" id="slider-clients">
        <h2 class="ui horizontal divider header">לקוחותינו</h2>

        <div class="owl-carousel owl-theme">
            <div class="item">
                <h4 class="tac">שמוליק קיפוד</h4>
                <p class="h4 tac">
                    אני מאוד מרוצה. השרות אדיב, האיכות מעל ממה שציפיתי, אופציות שונות של תשלום וההזמנה
                    הגיעה באריזת מתנה תוך 24 שעות.
                </p>
            </div>
            <div class="item">
                <h4 class="tac">קוקו</h4>
                <p class="h4 tac">שירות מעולה ומוצרים ברמה גבוהה מאוד!</p>
            </div>
            <div class="item">
                <h4 class="tac">דוד לוי</h4>
                <p class="h4 tac">שירות מעולה ומוצרים ברמה גבוהה מאוד!</p>
            </div>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/content/home.blade.php ENDPATH**/ ?>