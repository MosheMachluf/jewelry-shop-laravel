<?php $__env->startSection('cms_content'); ?>

<h2 class="ui horizontal divider header">האם אתה בטוח שברצונך למחוק מוצר זה?</h2>

<form class="ui form aligned center" action="<?php echo e(url("cms/products/$id")); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('DELETE')); ?>

    <a href="<?php echo e(url('cms/products')); ?>" class="ui button">בטל</a>
    <button class="ui red button" type="submit" name="submit">מחק</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/delete_product.blade.php ENDPATH**/ ?>