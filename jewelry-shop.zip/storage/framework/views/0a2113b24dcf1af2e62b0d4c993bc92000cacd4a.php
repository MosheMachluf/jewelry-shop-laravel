<?php
$err_link = $errors->first('link');
$err_title = $errors->first('title');
$err_url = $errors->first('url');
?>


<?php $__env->startSection('cms_content'); ?>

<h1>הוסף לינק</h1>
<div class="ui divider"></div>

<form class="ui form" action="<?php echo e(url('cms/menu')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <div class="field <?php echo e($err_link ? 'error' : null); ?>">
        <label for="link-field">לינק</label>
        <input type="text" name="link" id="link-field" placeholder="לינק" value="<?php echo e(old('link')); ?>">
        <span class="text-danger"><?php echo e($err_link); ?></span>
    </div>
    <div class="field <?php echo e($err_title ? 'error' : null); ?>">
        <label for="title-field">כותרת</label>
        <input type="text" name="title" id="title-field" placeholder="כותרת" value="<?php echo e(old('title')); ?>">
        <span class="text-danger"><?php echo e($err_title); ?></span>
    </div>
    <div class="field <?php echo e($err_url ? 'error' : null); ?>">
        <label for="url-field">כתובת הדף ( Url )</label>
        <input type="text" name="url" id="url-field" class="to-permalink" placeholder="כתובת הדף ( Url )"
            value="<?php echo e(old('url')); ?>">
        <span class="text-danger"><?php echo e($err_url); ?></span>
        <small>תווים מורשים: אותיות קטנות באנגלית ומקפים (-)</small>
    </div>

    <a href="<?php echo e(url('cms/menu')); ?>" class="ui button">חזור</a>
    <button class="ui primary button" type="submit" name="submit">הוסף</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/add_menu.blade.php ENDPATH**/ ?>