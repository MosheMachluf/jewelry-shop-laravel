<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title><?php echo e($title); ?></title>
    <script>
        const BASE_URL = "<?php echo e(url('')); ?>/";
    </script>
</head>

<body>

    <header>
        <nav class="ui inverted labeled icon menu">
            <div class="ui container">
                <a href="<?php echo e(url('')); ?>" class="center">
                    <img src="<?php echo e(asset('images/logo.png')); ?>">
                </a>
            </div>
        </nav>

        <div class="ui secondary pointing menu">
            <div class="ui container">
                <a class="item active" href="<?php echo e(url('')); ?>">דף הבית</a>
                <a class="item" href="<?php echo e(url('shop')); ?>">חנות</a>

                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="item" href="<?php echo e(url( $item['url'] )); ?>"><?php echo e($item['link']); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </header>

    <main>
        <div class="ui container">
            MAIN

            <?php echo $__env->yieldContent('main_content'); ?>
        </div>
    </main>



    <footer class="ui inverted vertical footer segment">
        FOOTER
    </footer>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/cms/master.blade.php ENDPATH**/ ?>