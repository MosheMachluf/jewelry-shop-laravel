<?php $__env->startSection('main_content'); ?>

<div class="ui container wide">
    <section class="section">

        <div class="row">
            <div class="ui secondary vertical pointing menu sidebar-categories">
                <div class="item">
                    <div class="header tac">קטגוריות</div>
                </div>
                <a href="<?php echo e(url($u = 'shop/sale')); ?>"
                    class="item text-danger <?php echo e($u == request()->path() ? 'active' : ''); ?>">
                    ★ SALE ★
                </a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url($u = 'shop/' . $category['url'])); ?>"
                    class="item <?php echo e($u == request()->path() ? 'active' : ''); ?>">
                    <?php echo e($category['title']); ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="products">
                <h1><?php echo e($title_page); ?></h1>

                <div class="ui divider"></div>

                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    

                    <?php $category = $product['category_url'] ?? $cat_url; ?>
                    <a href="<?php echo e(url("shop/$category/{$product['url']}")); ?>" class="product-item hover-img">
                        <div class="image">
                            <img src="<?php echo e(asset('images/' . $product['image'])); ?>" alt="<?php echo e($product['title']); ?>">
                        </div>
                        <h3 class="truncate"><?php echo e($product['title']); ?></h3>
                        <div class="number-format price <?php if($product['sale_price']): ?> original-price <?php endif; ?>">
                            &#8362;<?php echo e($product['price']); ?>

                        </div>
                        <?php if($product['sale_price']): ?>
                        <div class="number-format price">&#8362;<?php echo e($product['sale_price']); ?></div>
                        <?php endif; ?>
                    </a>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>
                        <h4>אין כרגע מוצרים בקטגוריה.</h4>
                    </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/content/products.blade.php ENDPATH**/ ?>