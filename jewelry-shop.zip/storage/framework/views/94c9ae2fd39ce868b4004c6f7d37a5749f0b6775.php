<?php $__env->startSection('main_content'); ?>

<div class="page-header bb-style text-style">
    <h1><?php echo e(str_replace('Mosh\'s Jewelry | ', '', $title)); ?></h1>
</div>

<div class="ui container">
    <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section class="section">
        <h2><?php echo e($content->title); ?></h2>
        <p><?php echo $content->article; ?></p>
    </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jewelry-shop\resources\views/content/content.blade.php ENDPATH**/ ?>